package com.example.Demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Demo.entity.Student;
import com.example.Demo.repo.Repo;

@Service
public class ServiceC {

	@Autowired
	Repo r;

	public Student createData(Student student) {

		return r.save(student);
	}

	public Student getData(Integer id) {
		// TODO Auto-generated method stub
		return r.findById(id).orElse(null);
	}

	public List<Student> getAll(Student stu) {
		// TODO Auto-generated method stub
		return r.findAll();
	}

}
