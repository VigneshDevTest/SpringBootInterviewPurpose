package com.example.Demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Demo.entity.Student;
import com.example.Demo.repo.Repo;
import com.example.Demo.service.ServiceC;

@RestController
@RequestMapping("/")
public class ControlC {

	@Autowired
	ServiceC serv;
//	Repo r;

	@PostMapping("post")
	public Student createData(@RequestBody Student student) {
		return serv.createData(student);
	}

	@GetMapping("get/{id}")
	public Student getData(@PathVariable Integer id) {

		return serv.getData(id);
	}

	@GetMapping("getAll")
	private List<Student> getAll(Student stu) {

		return serv.getAll(stu);
	}

}
