package com.example.Demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerCa {

	@RequestMapping("/jaa")
	private String getData(Model model) {
		
//		model.addAttribute("greets", "Java");
		
		return "index";

	}
	
}
